 (function () {
    const header = document.querySelector('.site-header');
    const btn = document.querySelector('.nav-toggle');
    const nav = document.getElementById('primary-nav');

    if (!header || !btn || !nav) return;

    // Toggle open/close
    function toggleNav(force) {
      const isOpen = typeof force === 'boolean'
        ? force
        : !header.classList.contains('is-open');

      header.classList.toggle('is-open', isOpen);
      btn.setAttribute('aria-expanded', String(isOpen));

      // Optional: lock body scroll when open on mobile
      document.documentElement.classList.toggle('nav-open', isOpen);
      document.body.style.overflow = isOpen ? 'hidden' : '';
    }

    btn.addEventListener('click', () => toggleNav());

    // Close when a nav link is clicked
    nav.addEventListener('click', (e) => {
      if (e.target.closest('a')) toggleNav(false);
    });

    // Close on Escape
    window.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') toggleNav(false);
    });

    // Safety: close if viewport grows to desktop
    const mql = window.matchMedia('(min-width: 769px)');
    mql.addEventListener('change', () => {
      if (mql.matches) toggleNav(false);
    });
  })();